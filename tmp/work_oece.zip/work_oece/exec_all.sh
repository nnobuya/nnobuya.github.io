#! /bin/bash

. ./exec_all.in

### parameter set
s_grav=( '14.12' '14.12' '14.12' '14.12' '14.12' '14.12' '14.12' '14.12' \ 
	 '14.38' '14.38' '14.38' '14.38' '14.38' '14.38' '14.38' '14.38' )
      # 1--8
      # 9--16

i_pres=( '22.40' '22.45' '22.50' '22.55' '22.60' '22.65' '22.70' '23.00' \
         '22.70' '22.75' '22.80' '22.85' '22.90' '22.95' '23.00' '23.20' )
      # 1--8
      # 9--16

### input file (iniphys.d)
t_init=('2e8'   '1e8' '1e8' '1e8' '1e8' '1e8' '1e8'  '1e8' \
        '2.5e8' '1e8' '1e8' '1e8' '1e8' '1e8' '1e8' '1e8' )
      # 1--8
      # 9--16

# total number of models ###########
n_model=${#i_pres[@]}


## only initial mode
if [ $initial == true ];
then
    echo ' ----- initial mode:'
    for i in `seq $mdl_st $mdl_en`; do

	no=`printf "%03d" $i`
	echo $no
	rm -rf ./run_$no
	rsync -a ./run_templete/ ./run_$no/
	ln -sf $exe_path ./run_$no

	ln -sf ../../inp_common/part/part-v3.z897 ./run_$no/inp/part.in
	ln -sf ../../inp_common/rate/rate-v3.z897c ./run_$no/inp/rate.in
	ln -sf ../../inp_common/rate/weak-v2.z897c ./run_$no/inp/weak.in
    done

    exit
else
    echo ' ----- run mode:'
fi
######################################



for i in `seq $mdl_st $mdl_en`; do

    no=`printf "%03d" $i`

    para1=${i_pres[$i-1]}
    para2=${s_grav[$i-1]}

    echo "#${no}:   P_i = ${para1}   g_s = ${para2}"

    cd ./run_$no


    cp ../inp_common/iniphys_t${t_init[$i-1]}.d ./inp/iniphys.d
    
#    nohup time ./flsh.out $para1 $para2 &
    time ./flsh.out $para1 $para2

    cd ../
done

exit
