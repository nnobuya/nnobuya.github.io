#! /bin/bash

no_st=3
no_ed=3

rm -rf ./res

for no in `seq -f "%03g" $no_st $no_ed`
do

    echo $no

    ln -sf ../run_$no/res/abun.dat abun.d
    ln -sf ../run_$no/res/phys.d

    mkdir ./res

    ./rd_flsh_out


    rm -rf   ./res_$no
    mv ./res ./res_$no

done

rm ./abun.d
rm ./phys.d

exit
