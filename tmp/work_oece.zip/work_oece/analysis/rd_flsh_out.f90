program rd_flsh_out

  implicit none

  integer, parameter:: nucl_z = 60, nucl_a = 160
  integer, parameter:: nout = 10
  
  integer:: nucl, nucl_out
  real:: ti, dti, de, te, epsln, enu, erad, ye, yi, bi, opac, cp, epn, epnr, epnt, aash
  real, allocatable:: y(:)!, x(:)
  integer, allocatable:: ia(:), in(:), iz(:)
  character, allocatable:: name(:)*5

  real:: y_z(0:nucl_z), y_a(0:nucl_a)
  character:: f_open*100
  
  real:: t9
  integer:: istp, ier, i, j, i_out


  
  ! ------------------------------------------------------------------ !
  !     open files                                                     !
  ! ------------------------------------------------------------------ !
  
  open(50, file = './phys.d', action = 'read')
  !NN open(51, file = './abun.d', action = 'read', form = 'unformatted')
  

  open(60, file = './res/hydro.dat'     , action = 'write')
  open(61, file = './res/abund_evol.dat', action = 'write')
  open(62, file = './res/f_abund.dat'   , action = 'write')
  open(64, file = './res/f_abund_a.dat' , action = 'write')
  open(65, file = './res/phys.dat'      , action = 'write')
  
  !     end open files                                                 !
  ! ------------------------------------------------------------------ !
  

  write(60,'("#     time [s]            t9 [GK]             density [g/cc]")') 
  write(65,'("#", *(a15))') 'ti', 'dti', 'de', 'te', 'epsln', 'enu', 'erad', &
       & 'ye', 'yi', 'bi', 'opac', 'cp', 'epn', 'epnr', 'epnt', 'aash'

  rd_phys: do
     read(50,*,iostat=ier) istp
     if (ier /= 0) exit rd_phys

     !write(*,*) istp
     
     read(50,*)
     read(50,*) ti, dti, de, te, epsln
     read(50,*)
     read(50,*) enu, erad, ye, yi, bi
     read(50,*)
     read(50,*) opac, cp, epn, epnr, epnt
     read(50,*)
     read(50,*) aash

     t9 = te *1.e-9
     write(60,'(*(es20.10))') ti, t9, de
     write(65,'(*(es15.7))') ti, dti, de, te, epsln, enu, erad, &
          & ye, yi, bi, opac, cp, epn, epnr, epnt, aash

  end do rd_phys
  
  close(50)

  stop 'OECE2026'
  
  read(51) nucl

  allocate( y(1:nucl), name(1:nucl), ia(1:nucl), in(1:nucl), iz(1:nucl) )

  read(51) ia(1:nucl), iz(1:nucl)
  in(1:nucl) = ia(1:nucl) - iz(1:nucl)
  read(51) name(1:nucl)

  i = 0
  i_out = 0
  rd_abun: do
     read(51, iostat = ier) ti, nucl_out
     if (ier /= 0) exit rd_abun

     y(1:nucl) = 0.0
     read(51) y(1:nucl_out)

     !..isobar & isotope
     y_z(0:nucl_z) = 0.0
     y_a(0:nucl_a) = 0.0
     do j = 1, nucl
        y_z(iz(j)) = y_z(iz(j)) + y(j)
        y_a(ia(j)) = y_a(ia(j)) + y(j)
     end do
     

     i = i + 1

     if ( mod(i,nout) == 0 ) &
          & write(61,'(*(es14.5))') ti, y(1:nucl_out)


     if (mod(i,1000) == 0) then
        i_out = i_out + 1
        write(f_open,'("./res/abund_", i5.5, ".dat")') i_out
        open(63,file = f_open, action = 'write')
        do j = 1, nucl
           write(63,'(3i5,es15.7)') iz(j), in(j), ia(j), y(j)
        end do
        write(63,*)
        write(63,*)
        do j = 0, nucl_a
           write(63,'(i5,es15.7)') j, y_a(j)
        end do

        close(63)
     end if

  end do rd_abun

  do j = 1, nucl
     write(62,'(3i5,es15.7)') iz(j), in(j), ia(j), y(j)
  end do

  do j = 0, nucl_a
     write(64,'(i5,es15.7)') j, y_a(j)
  end do

  close(51)
  close(61)
  close(62)
  close(64)


  
  stop 'normal temination'

end program rd_flsh_out
