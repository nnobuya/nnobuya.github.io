!#######################################################################
!##
!##    Electron thermal conductivity in a neutron star core
!##  ,assuming the matter consists of n,p,e and not including the 
!##  effects of superfluidity.
!##
!##  Auther: Y.Matsuo
!##  Date  : June 12, 2015
!##
!##  Reference.
!##    1. Gnedin & Yakovrev, Nucl. Phys. A, 582,697,(1995)
!##    2. : Baiko et al., Astron. Astrophys., 374,151,(2001)
!##
!##  electron : (14.2 <= log\rho < 15.4 ) [1] --- very simple formulae
!##  neutron  : (14 <= log\rho <= 14.9 )  [2] --- have not been included, yet
!##
!#######################################################################
subroutine condecore(T,rho,Ye, kap)
  use opacparam
  implicit none
!===== DECLARATIVE PART ================================================
  !===== Arguments =====
  real(8),intent(in) :: T,rho,Ye
  real(8),intent(out) :: kap

  real(8),parameter :: mpeff = 0.7d0
  real(8),parameter :: C    = 1.2d0
  real(8),parameter :: r76  = 7.d0/6.d0

  !===
  real(8) :: T8

  real(8) :: ne

!===== PROGRAM BEGIN ===================================================

  T8  = T*1.d-8

  !=== Calc electron thermal conductivity (see eq.(70) in ref.[1]) ===
  ne = rho*NA*Ye
  kap  = 6.3d24 * C * (ne/n0)**(r76) / (T8*sqrt(mpeff))


!===== PROGRAM END =====================================================
  return
end subroutine condecore
