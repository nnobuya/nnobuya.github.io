#!/opt/gnuplot/bin/gnuplot

set term postscript enhanced color fontfile 'cmsy10.pfa'
set output 'cmp_opac.ps'

set size 0.7
set tmargin 2
#set grid

set xlabel 'log {/Symbol-Oblique r} (g cm^{-3})'
set ylabel 'log {/Symbol-Oblique k} (cm^2 g^{-1})'
set mxtics 2

set label  1 '~{/Times-Italic M}{ .5 \264} = 1.0 {/Symbol \264} 10^{-9} {/Times-Italic M}_{/CMSY10 \014} yr^{-1}' at 1,-40
set label 11 "0.75 {/Time-Italic M}_{/CMSY10 \014} \n L.E. (-0)" at 6,2.5
set label 12 "2.01 {/Time-Italic M}_{/CMSY10 \014} \n L.E. (-15)" at 5,-12
set label 13 "0.75 {/Time-Italic M}_{/CMSY10 \014} \n Ni (-5)" at 10,-18
set label 14 "2.01 {/Time-Italic M}_{/CMSY10 \014} \n Ni (-20)" at 10.5,-37

shift1=0.
shift2=15.
shift3=5.
shift4=20.

file1 = '../out/0.75Msun_H.dat'
file2 = '../out/2.01Msun_H.dat'

file3 = '../out/0.75Msun_Ni.dat'
file4 = '../out/2.01Msun_Ni.dat'

p file1 u 2:($6-shift1) w l lw 3 lc 1 lt 1 t '' \
, file1 u 2:($5-shift1) w l lw 3 lc 3 lt 2 t '' \
, file2 u 2:($6-shift2) w l lw 3 lc 1 lt 1 t '' \
, file2 u 2:($5-shift2) w l lw 3 lc 3 lt 2 t '' \
, file3 u 2:($6-shift3) w l lw 3 lc 1 lt 1 t '' \
, file3 u 2:($5-shift3) w l lw 3 lc 3 lt 2 t '' \
, file4 u 2:($6-shift4) w l lw 3 lc 1 lt 1 t '' \
, file4 u 2:($5-shift4) w l lw 3 lc 3 lt 2 t '' \