subroutine radopac(nucl,T,rho,Ye,Z,y, opacrad)
  implicit none
!===== DECLARATIVE PART ================================================

  !===== Arguments =====
  integer,intent(in) :: nucl
  real(8),intent(in) :: rho,t,Ye
  integer,intent(in) :: Z(nucl)
  real(8),intent(in) :: y(nucl)
  real(8),intent(out) :: opacrad

  !=====
  integer,parameter :: He4 = 6
  real(8) :: X4

  !=====
  real(8) :: opacff,opaces,opacab

  !===== Note =====
  !  Reference
  !   1. H.Schatz, L.Bildsten, and A. Cumming, Astrophys.J.,524,1014,(1999)
  !   2. B.Paczynski, Astrophys.J.,267,315,(1983)
  !

!===== PROGRAM BEGIN ===================================================


  !=== Free-Free opacity [1] =====
  call radopac_ff(nucl,rho,T,Ye,Z,y, opacff)


  !=== Electron scattering [2] =====
  opaces  = 0.4d0 * Ye * (1.d0+2.7d11*rho*T**(-2)) * &
       & (1.d0+2.0833d-9*T)**(-0.86d0)

  !=== Absorption opacity [2] =====
  X4 = y(He4)*4.d0
  opacab  = 4.d25*(1.001-X4)*rho*T**(-3.5d0) ! <--- this may be wrong ?


  !=== Radiation opacity =====
  opacrad = opacff + opaces !+ opacab


!===== PROGRAM END =====================================================
  return
end subroutine radopac

!#######################################################################
!##
!##  Opacity for free-free scattering
!##
!##  Reference
!##   1. H.Schatz, L.Bildsten, and A. Cumming, Astrophys.J.,524,1014,(1999)
!##   2. G.Chabrier & A.Y.Potekhin, Phys. Rev. E, 58,4941,(1998)
!##
!#######################################################################

subroutine radopac_ff(nucl,rho,T,Ye,Z,y, opac)
  use opacparam
  implicit none
!===== DECLARATIVE PART ================================================

  !===== Arguments =====
  integer,intent(in) :: nucl
  real(8),intent(in) :: rho,t,Ye  !--- cgs unit
  integer,intent(in) :: Z(nucl)
  real(8),intent(in) :: y(nucl)
  real(8),intent(out) :: opac !--- cgs unit

  !===== Parameters =====
  real(8),parameter :: u = 10.d0

  !=====
  real(8) :: ne,T8,rho5

  real(8) :: pFc,xx, TF,theta,expth,expmth,tau
  real(8) :: f,chi_nr
  real(8) :: q1,q2,q3, chi_rc, eta

  real(8) :: nQ2ne,gam(nucl),LPI, gff(nucl)
  real(8) :: deg_corr, Elwert_fac, rel_corr
  real(8) :: z2gff

  !===== Working Variables =====
  integer :: k

!===== PROGRAM BEGIN ===================================================

  ne   = rho * NA * Ye * fm3  !--- electron number density [fm^{-3}]
  rho5 = rho*1.d-5
  T8   = T*1.d-8

  !===== Calculate the Gaunt factor (see ref.[1])======================

  !===== Calc 2*nQ/ne (see eq.(A3) in ref.[2]) =====
  nQ2ne = 0.08d0 * T8*sqrt(T8) / (Ye*rho5)

  !===== Calc gamma (see eq.(A4) in ref.[2]) =====
  do k = 1, nucl
     gam(k) = sqrt(1.58d-3 * Z(k)**2 / T8)
  end do

  !===== Calc PI (see eq.(A5) in ref.[2]) =====
  !--- Fermi momentum * c [MeV*fm] ---
  pFc = hbc * (3.d0*pi**2*ne)**(1.d0/3.d0)

  !--- Fermi temperature [K] ---
  xx = (pFc / me) ** 2
  TF = me/kb * xx / ( sqrt(1.d0+xx)+1.d0 )

  !--- non. rel. mu/kT (chi_nr)---
  f = 2.d0/3.d0 * (TF/T) * sqrt(TF/T)
  chi_nr = inv_fermi_integ12(f)

  !--- rel. correction for mu/kT (chi_rc)---
  theta = T / TF
  if ( theta < 5.d2 ) then
     expth  = exp(theta)
     expmth = 1.d0/expth
     tau = kb*T/me

     q1 = 1.5d0 / (expth-1.d0)
     q2 = 12.d0 + 8.d0/(theta*sqrt(theta))
     q3 = 2.d0/pi**(1.d0/3.d0) - &
          & (expmth+1.612d0*expth) / &
          & (6.912d0*theta**9.44d-2*expmth+5.535d0*theta**0.698d0*expth)

     chi_rc = -1.5d0*log( 1.d0 + &
          & tau / (1.d0+q2*tau) * &
          & (1.d0+q1*sqrt(tau)+q2*q3*tau) / (1.d0+0.5d0*tau/theta) )

  else  !--- to avoid the numrical divergence
     tau = kb*T/me

     q2 = 12.d0 + 8.d0/(theta*sqrt(theta))
     q3 = 2.d0/pi**(1.d0/3.d0) - &
          & 1.612d0 / (5.535d0*theta**0.698d0)

     chi_rc = -1.5d0*log( 1.d0 + &
          & tau*(1.d0+q2*q3*tau) / &
          & ((1.d0+0.5d0*tau/theta)*(1.d0+q2*tau)) )
  end if
     

  !--- degeneracy parameter (mu/kT) ---
  eta = chi_nr + chi_rc

  !--- PI ---
  if ( eta < 0.d0 ) then
     LPI = (1.d0+log(1.d0+exp(eta)))**(2.d0/3.d0)
  else
     LPI = (1.d0+eta+log(1.d0+exp(-eta)))**(2.d0/3.d0)
  end if

  !===== Calc Gaunt factor (gff) =====

  !--- degeneracy correction ---
  if ( eta < 0.d0 ) then
     deg_corr   = nQ2ne*(log(1.d0+exp(eta)))
  else
     deg_corr   = nQ2ne*(eta + log(1.d0+exp(-eta)))
  end if

  !--- effects of the relativity on Coulomb scattering ---
  rel_corr   = ( 1.d0 + (T8/7.7d0)*sqrt(T8/7.7d0) )

  do k = 1, nucl
     !--- Elwert factor ---
     if ( Z(k) /= 0 ) then
        Elwert_fac = ( 1.d0 - exp(-2.d0*pi*gam(k)/sqrt(LPI+u)) ) / &
             & ( 1.d0 - exp(-2.d0*pi*gam(k)/sqrt(LPI)) )
     else
        Elwert_fac = sqrt(LPI/(LPI+u))
     end if

     !--- Gaunt factor ---
     gff(k) = 1.16d0 * deg_corr * Elwert_fac * rel_corr

  end do


  !===== Calculate the free-free opacity ===============================
  z2gff = 0.d0
  do k = 1, nucl
     if ( z(k) == 0 ) cycle
     z2gff = z2gff + Z(k)**2*y(k)*gff(k)
  end do

  !===== Free-free opacity =====
  opac = 0.753d0*rho5*Ye*T8**(-3.5d0) * z2gff

!===== PROGRAM END =====================================================
  return

contains

!========================================================================
!==
!== Calc the inverse fermi integral (n=1/2)  (see eq.(6) in Antia(1993))
!==
!========================================================================
!==  Reference
!==    H.M.Antia, Astrophys. J.,84,101,(1993)
!==
!========================================================================

  real(8) function inv_fermi_integ12(f) result (result)
    implicit none
  !===== DECLARATIVE PART =============================================

    !===== Arguments ========
    real(8),intent(in) :: f

    !===== Parameters =======
    integer,parameter :: m1 = 4, k1 = 3,  m2 = 6, k2 = 5
    real(8),parameter :: a(0:m1) =  &
         & (/ 1.999266880833d+4, 5.702479099336d+3, 6.610132843877d+2, &
         &    3.818838129486d+1, 1.000000000000d+0 /)
    real(8),parameter :: b(0:k1) = &
         & (/ 1.771804140488d+4,-2.014785161019d+3, 9.130355392717d+1, &
         &   -1.670718177489d0 /)
    real(8),parameter :: c(0:m2) = &
         & (/-1.277060388085d-2, 7.187946804945d-2,-4.262314235106d-1, &
         &    4.997559426872d-1,-1.285579118012d+0,-3.930805454272d-1, &
         &    1.000000000000d+0 /)
    real(8),parameter :: d(0:k2) = &
         & (/-9.745794806288d-3, 5.485432756838d-2,-3.299466243260d-1, &
         &    4.077841975923d-1,-1.145531476975d+0,-6.067091689181d-2 /)

    !=====
    real(8) :: x
    real(8) :: numer,denom
    real(8) :: R1,R2
    integer :: i

  !===== PROGRAM BEGIN =================================================

    if ( f < 4.d0 ) then
       x = f
       numer = a(m1)
       do i = m1-1, 0, -1
          numer = numer*x + a(i)
       end do
       denom = b(k1)
       do i = k1-1, 0, -1
          denom = denom*x + b(i)
       end do
       R1 = numer/denom

       result = log( R1 * x )
    else
       x = f**(-2.d0/3.d0)
       numer = c(m2)
       do i = m2-1, 0, -1
          numer = numer*x + c(i)
       end do
       denom = d(k2)
       do i = k2-1, 0, -1
          denom = denom*x + d(i)
       end do
       R2 = numer/denom

       result = R2 / x
    end if

  !===== PROGRAM END ==================================================
    return
  end function inv_fermi_integ12
    
end subroutine radopac_ff
