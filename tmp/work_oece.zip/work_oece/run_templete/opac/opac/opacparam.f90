module opacparam
  implicit none

  !=====
  real(8),parameter :: pi = acos(-1.d0)

  !===== Physical Constant =====
  real(8),parameter :: fm3 = 1.d-39
  real(8),parameter :: amu = 1.66d-24      !--- Atomic mass unit [g]
  real(8),parameter :: NA  = 6.02214129d23 !--- mol^{-1}
  real(8),parameter :: sgm = 5.670373d-5   !--- Stefan-Boltzmann constant [erg / cm^2 K^4 s]

  real(8),parameter :: me = 0.510998928d0   !--- Electron mass [MeV]
  real(8),parameter :: hbc = 197.3269718d0  !--- hbar * c [MeV*fm]
  real(8),parameter :: kb = 8.6173324d-11   !--- Boltzmann constant [MeV/K]

  !=====
  real(8),parameter :: n0 = 0.16d0 / fm3        !--- nuclear number density [/cm^3]
  real(8),parameter :: rholg0 = log10(amu * n0) !--- 14.424: log nuclear density [g/cm^3] 
end module opacparam
