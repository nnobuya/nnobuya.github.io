program test
  implicit none
!===== DECLARATIVE PART ====================================================

  !===== Parameters =====
  integer,parameter :: nucl = 3
!  integer,parameter :: nrho = 349, nT = 5
!  real(8),parameter :: rholg1 = -2.d0, rholg2 = 15.4d0
!  real(8),parameter :: Tlg1   =  5.d0, Tlg2   = 8.9999999d0
  integer,parameter :: nrho = 349, nT = 4
  real(8),parameter :: rholg1 = -2.d0, rholg2 = 15.4d0
  real(8),parameter :: Tlg1   = 6.d0, Tlg2   = 8.99999d0


  !=====
  real(8) :: drholg, dTlg
  real(8) :: rholg(nrho), Tlg(nT),Ye(nrho)
  integer :: Z(nucl),A(nucl)
  real(8) :: x(nucl,nrho),y(nucl,nrho)

  real(8) :: rho,T,yy(nucl),YYe
  real(8) :: opac,opat,opar

  !=====
  integer :: i,j,k

!===== PROGRAM BEGIN =======================================================

  !--- open -----
  open(unit=21,file='./out/opac.dat',action='write')

  !---- density -----
  rholg(1) = rholg1
  drholg = (rholg2-rholg1)/dble(max(nrho-1,1))
  do i = 2, nrho
     rholg(i) = rholg(i-1) + drholg
  end do

  !----- temperature -----
  Tlg(1) = Tlg1
  dTlg = (Tlg2-Tlg1)/dble(max(1,nT-1))
  do j = 2, nT
     Tlg(j) = Tlg(j-1) + dTlg
  end do

  !----- abundance -----
!  Z(1) = 26  !--- Fe
!  A(1) = 56
!  x(1) = 1.d0

  Z(1) = 1  !--- H
  A(1) = 1
  Z(2) = 2  !--- He
  A(2) = 4
  Z(3) = 28 !--- Ni
  A(3) = 56

  do i = 1, nrho
     if ( rholg(i) <= 6.d0 ) then
        x(1,i) = 0.70d0
        x(2,i) = 0.25d0
        x(3,i) = 0.02d0

        Ye(i) = 0.d0
        do k = 1, nucl
           Ye(i) = Ye(i) + dble(Z(k))/dble(A(k))*x(k,i)
        end do
        do k = 1, nucl
           y(k,i) = x(k,i)/A(k)
        end do
     else
        x(1,i) = 0.d0
        x(2,i) = 0.d0
        x(3,i) = 1.d0

        Ye(i) = 0.2d0
        do k = 1, nucl
           y(k,i) = x(k,i)/A(k)
        end do
     end if

  end do

  !----- opacity -----
  do j = 1, nT
     T = Tlg(j)
     write(21,'(a2,i4,a,f10.5)') '# ',j-1, ',  Tlg =',T
     write(21,'(a2,2a4,3a8,3a12)') '# ','i','j','rholg','Tlg','Ye',&
          & 'opac','opat','opar'

     do i = 1, nrho
        rho = rholg(i)
        YYe = Ye(i)
        do k = 1, nucl
           yy(k) = y(k,i)
        end do

        call opacity(nucl,T,rho,YYe,Z,yy, opac)
        opat = 0.d0
        opar = 0.d0

        write(21,'(2x,2i4,3f8.4,3es12.4,10es14.4e3)') &
             & i,j, rho,T,YYe, opac,opat,opar, &
             & (x(k,i),k=1,nucl)
     end do

     write(21,'(/)')
  end do

!===== PROGRAM END =========================================================
  write(*,'(a)') '### Normal Finish ###'
  stop
end program test
