!#######################################################################
!##
!##  Opacities for a neutron star
!##
!##  Author: Y.Matsuo
!##  Date: June 9, 2015
!##
!## ###
!##
!## <Conductive Opacity>
!##   'condinter'
!##   'condegsc'
!##   'condecore'
!##
!##
!## <Radiation Opacity>
!##   'radopac'
!##
!#######################################################################

subroutine opacity(nucl,Tlg,rholg,Ye,Z,y, opaclg)
  use opacparam
  implicit none
!===== DELCARATIVE PART ================================================

  !===== Arguments ==========================
  integer,intent(in) :: nucl
  real(8),intent(in) :: Tlg,rholg,Ye
  integer,intent(in) :: Z(nucl)
  real(8),intent(in) :: y(nucl)
  real(8),intent(out) :: opaclg

  !=====
  real(8) :: opac
  real(8) :: opaccond, opacrad

  real(8) :: kap_cond  !--- thermal conductivity

  !=====
  real(8) :: rho,temp
  real(8) :: n,ni(nucl)
  real(8) :: Zave,Zimp

  real(8) :: b12

  !===== Working Variables =====
  integer :: i
  real(8) :: dum1,dum2,dum3,dum4,dum5

!===== PROGRAM BEGIN ===================================================

  rho  = 10.d0**rholg
  temp = 10.d0**tlg

  n = 0.d0
  Zave  = 0.d0
  do i = 1, nucl
     ni(i) = rho*NA*y(i)
     n = n + ni(i)
     Zave  = Zave  + Z(i)*ni(i)
  end do
  Zave  = Zave/n

  Zimp = 0.d0
  do i = 1, nucl
     Zimp = Zimp + ni(i)*(Z(i)-Zave)**2
  end do
  Zimp = Zimp/n

  !=====================================================================
  !===  Conductive Opacities ===
  !=====================================================================

  !===== Electron thermal conductivity =====
  if (    3.d0 <= Tlg   .and.   Tlg <= 9.d0 .and. &
       & -6.d0 <= rholg .and. rholg <= 9.75d0 ) then
     !=== Envelop  <=>  Boundary between the inner and outer crust ===

     if ( Zave > 60.d0 ) Zave = 60.0d0
     
     call coninter(Zave,Tlg,rholg,kap_cond,dum1,dum2)
     kap_cond = 10.d0**(kap_cond)

  else if ( rholg < rholg0 - log10(2.d0) ) then
     !=== Boundary between the inner and outer crust <=> 
     !                  Boundary between the innter crust and core ===

     b12 = 0.d0
     call condegsc(Tlg,rholg,b12,Zimp, &
          & dum1,dum2,dum3,kap_cond,dum4,dum5)

  else if ( rholg <= rholg0 + 1.2d0 ) then
     !=== Neutron star core ===
     call condecore(temp,rho,Ye, kap_cond)

  !===
  else
     write(0,'(a)') '### Error:opacity2.f90 ###'
     write(0,'(2x,a)') 'Out of tables of electron conductive opacity'
     write(0,'(5x,a,2f7.3,a)') '(rholg,Tlg) = (',rholg,Tlg,')'
     stop 2
  end if

  !====== Neutron thermal conductivity =====


  !======
  opaccond = 16.d0*sgm*temp**3 / (3.d0*rho*kap_cond)
  
  !=====================================================================
  !=== Radiative Opacities ===
  !=====================================================================

  call radopac(nucl,temp,rho,Ye,Z,y, opacrad)


  !=====================================================================
  !=== Total ===
  !=====================================================================

  opac = opaccond*opacrad / ( opaccond + opacrad )

  opaclg = log10(opac)

!===== PROGRAM END =====================================================
  return
end subroutine opacity
