program test2
  implicit none
!===== DECLARATIVE PART ================================================

  !===
  integer,parameter :: nmax = 500
  integer,parameter :: nucl = 5
  integer,parameter :: Z(nucl) = (/ 1, 2,  6,  8, 26 /)
  integer,parameter :: A(nucl) = (/ 1, 4, 12, 16, 56 /)

  character(6),parameter :: name(nucl) = &
       & (/ '    H1','   He4','   C12','   O16','  Ni56' /)

  !===
  integer :: ndiv
  real(8) :: rho(nmax),T(nmax),Ye(nmax)
  real(8) :: mfrac(nucl,nmax)

  !===
  real(8) :: rholg,Tlg,YYe,y(nucl), opaclg_new

  !===
  integer :: istat, i,k
  integer :: idum
  real(8) :: rdum1,rdum2,rdum3,rdum4
  character(256) :: cdata

!===== PROGRAM BEGIN ===================================================

  !===== Open files ====
  open(unit=11,file='../../opac_XRB/opac.d',action='read',status='old')
  open(unit=21,file='./out/opac2.dat',action='write',status='new')

  write(21,'(a2,a4,2a8,10a12)') &
       & '# ', 'i','rholg','Tlg','Ye','opaclg_new', (trim(name(k)),k=1,nucl)

  !===== Read the rho,T,Ye,mfrac =====
  i = 0
  do
     read(11,'(a256)',iostat=istat) cdata
     if ( istat < 0 ) exit
     if ( cdata(1:1) == '#' ) cycle

     i = i + 1
     read(cdata,*) &
          & idum,rho(i),T(i),rdum1,Ye(i), &
          & (mfrac(k,i),k=1,nucl),rdum2,rdum3,rdum4
  end do
  close(11)
  ndiv = i

  !=====
  do i = 1, ndiv
     rholg = rho(i)
     Tlg   = T(i)
     YYe   = Ye(i)
     do k = 1, nucl
        y(k) = mfrac(k,i)/A(k)
     end do
     
     call opacity(nucl,Tlg,rholg,YYe,Z,y, opaclg_new)

     write(21,'(2x,i4,2f8.4,10es12.4)') &
          & i, rholg,Tlg,YYe,opaclg_new,(mfrac(k,i),k=1,nucl)
  end do

!===== PROGRAM END =====================================================
  write(*,'(a)') '### Normal Finish ###'
  stop
end program test2
