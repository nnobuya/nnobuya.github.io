program test3
  implicit none
!===== DECLARATIVE PART ================================================

  !===
  integer,parameter :: nmax = 500
  integer,parameter :: nucl = 16

  integer,parameter :: Z(nucl) = &
       & (/ 1,2,6,8,8, 8,9,12,16,28, 30,32,30,32,34, 32 /)
  integer,parameter :: A(nucl) = &
       & (/ 1,4,12,14,15, 16,17,22,30,56, 60,60,64,64,68, 68  /)
  character(6),parameter :: name(nucl) = &
       & (/ '    H1','   He4','   C12','   O14','   O15', &
       &    '   O16','   F17','  Mg22','   S30','  Ni56', &
       &    '  Zn60','  Ni60','  Ge64','  Zn64','  Se68', &
       &    '  Ge68' /)

  !===
  integer :: ndiv
  real(8) :: logQ(nmax),rad(nmax)
  real(8) :: dens(nmax),pres(nmax),temp(nmax),opac(nmax),Ye(nmax)
  real(8) :: mfrac(nucl,nmax)

  !===
  real(8) :: rholg,Tlg,YYe,y(nucl), opaclg_old,opaclg_new

  !===
  integer :: istat, i,k
  integer :: idum
  character(500) :: cdata

  !===
  integer :: idata

!===== PROGRAM BEGIN ===================================================

  idata = 0
  1 continue

  !===== Open files ====
  idata = idata + 1

  if ( idata == 1 ) then
     open(unit=11,file='../../hayashida_strc/0.75Msun_H_opac0.dat',action='read',status='old')
     open(unit=21,file='./out/0.75Msun_H.dat',action='write',status='new')
  else if ( idata == 2 ) then
     open(unit=11,file='../../hayashida_strc/0.75Msun_Ni_opac0.dat',action='read',status='old')
     open(unit=21,file='./out/0.75Msun_Ni.dat',action='write',status='new')
  else if ( idata == 3 ) then
     open(unit=11,file='../../hayashida_strc/2.01Msun_H_opac0.dat',action='read',status='old')
     open(unit=21,file='./out/2.01Msun_H.dat',action='write',status='new')
  else if ( idata == 4 ) then
     open(unit=11,file='../../hayashida_strc/2.01Msun_Ni_opac0.dat',action='read',status='old')
     open(unit=21,file='./out/2.01Msun_Ni.dat',action='write',status='new')
  end if

  write(21,'(a2,a4,2a8,20a12)') &
       & '# ', 'i','rholg','Tlg','Ye','opaclg_old','opaclg_new', (trim(name(k)),k=1,nucl)

  !===== Read the data (unit=11) =====
  i = 0
  do
     read(11,'(a500)',iostat=istat) cdata
     if ( istat < 0 ) exit
     if ( cdata(1:1) == '#' .or. cdata(1:7) == '' ) cycle

     i = i + 1
     read(cdata,*) &
          & idum,logQ(i),rad(i), &
          & dens(i),pres(i),temp(i),opac(i),Ye(i), &
          & (mfrac(k,i),k=1,nucl)
  end do
  ndiv = i
  close(11)

  !=====
  do i = 1, ndiv
     rholg = dens(i)
     Tlg   = temp(i)
     YYe   = Ye(i)
     do k = 1, nucl
        y(k) = mfrac(k,i)/A(k)
     end do
     
     call opacity(nucl,Tlg,rholg,YYe,Z,y, opaclg_new)

     opaclg_old = opac(i)

     write(21,'(2x,i4,2f8.4,20es12.4)') &
          & i, rholg,Tlg,YYe,opaclg_old,opaclg_new,(mfrac(k,i),k=1,nucl)
  end do
  close(21)

  if ( idata < 4 ) go to 1

!===== PROGRAM END =====================================================
  write(*,'(a)') '### Normal Finish ###'
  stop
end program test3
