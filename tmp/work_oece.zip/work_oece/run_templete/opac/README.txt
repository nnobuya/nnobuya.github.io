
#======================================================================
#  Y.Matsuo
#======================================================================

<Opacities in Neutron Star>

***** condint.f ********************************
  <Purpose>
     * Get the thermal conductivities from 'condall06.d'
  <INPUT>
     * Zion --- ion charge ( 1 <= Zion <= 60 )
     * TLG  --- log T (K)  ( 3 <= TLG <= 9   )
     * RLG  --- log\rho (g cm^{-3}) ( -6 <= RLG <= 9.75 )
  <OUTPUT>
     * CK  --- decimal logarithm of thermal conductivity \kappa (erg cm^{-1} s^{-1} K^{-1})
     * DRK --- dlog\kappa/dlog\rho
     * DTK --- dlog\kappa/dlogT

***** condegsc13.f *****************************
  <Purpose>
     * Calculation the conductivities in the inner crust of a neutron star
  <INPUT>
     * Tlg   --- log T (K)
     * RHOlg --- log\rho (g cm^{-3})
     * B12   --- magnetic field (10^{12} gauss)
     * Zimp  --- impurity parameter ( = < n_j (Z-Z_j)^2 > / n )
  <OUTPUT>
     * SIGMA  --- longitudinal electric conductivity
     * SIGMAT --- transverse   electric conductivity
     * SIGMAH --- off-diagonal electric conductivity
     * CKAPPA  --- longitudinal thermal conductivities (erg cm^{-1} s^{-1} K^{-1})
     * CKAPPAT --- transverse   thermal conductivities (erg cm^{-1} s^{-1} K^{-1})
     * CKAPPAH --- off-diagonal thermal conductivities (erg cm^{-1} s^{-1} K^{-1})
  <NOTE>
     * If Zimp = 0, log\rho <= 14.708

#========================================================================

<Main Program>
   You can perform the test simulation of 3 pettern by the modified the variable of SRC in 'makefile'.
     * test.f90   --- You give the density, temperature, Ye, and mass fraction
     * test2.f90  --- Read the density,temperature,Ye, and mass fraction from 'opac.d'
                      which is made from XRB code by Y.Matsuo
     * test3.f90  --- Read the density,temperature,Ye, and mass fraction from Hayashida's data
