         nvalc         nvalp          nstg        nwrite          nlog
             3            10        999999           100           100
          eps0          del0         timen
   1.00000e-06   1.00000e-99   1.00000e+04
