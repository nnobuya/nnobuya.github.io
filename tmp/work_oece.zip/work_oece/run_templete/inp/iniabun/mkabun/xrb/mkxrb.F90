#define DEBUG
program mkxrb
  implicit none
!##### DECLARATIVE PART ################################################

  !===== part.z =====
  character(128),parameter :: filep = '../../../part/part.z897'
  integer,parameter :: nprt = 24
  integer :: nucl
  character(6),allocatable :: name(:)
  integer,allocatable :: a(:),z(:),n(:)
  real(8),allocatable :: spin(:),qm(:),cpart(:,:)
  real(8),allocatable :: mfrac(:)

  !=== for Output
  integer,parameter :: nprocs = 6

  !===== Working Variables =====
  integer :: istat,ipr,k,l
  real(8) :: fac

!##### PROGRAM BEGIN ###################################################


  !===== Open the files ==========================
  !--- input files ---
  open(unit=11,file=filep,action='read',status='old')

  !--- output file ---
  open(unit=21,file='iniabun_xrb.d',action='write',status='unknown')


  !===== Read the files ==========================
  !--- part.z897 ---
  read(11,*) nucl
  allocate(name(nucl))
  allocate(a(nucl),z(nucl),n(nucl))
  allocate(spin(nucl),qm(nucl),cpart(nprt,nucl))

  do ipr = 1, nucl

     read(11,*,iostat=istat) &
          & name(ipr),a(ipr),z(ipr),n(ipr),spin(ipr),qm(ipr)
     if ( istat /= 0 ) then
        write(0,'(a)') "Error: Cannot read 'part.z*'"
        write(0,'(5x,a,i3,a,i3)') 'istat =',istat, ', ipr =',ipr
        if ( ipr /= 1 ) write(0,'(5x,a5,3i4,f10.1,f10.3)') &
             & name(ipr-1),a(ipr-1),z(ipr-1),n(ipr-1), &
             & spin(ipr-1),qm(ipr-1)
        stop 1
     end if

     do k = 1, 3
        read(11,'(8es14.5)') (cpart(l,ipr), l=8*k-7,min(8*k,nprocs))
     end do
     if ( istat /= 0 ) then
        write(0,'(a)') "Error: Cannot read 'part.z*'"
        write(0,'(5x,a,i3)') 'istat =',istat
        write(0,'(5x,a5,3i4,f10.1,f10.3)') &
             & name(ipr),a(ipr),z(ipr),n(ipr),spin(ipr),qm(ipr)
        stop 2
     end if

#ifdef DEBUG
     if ( ipr < 10 ) then
        write(*,'(i5,2x,a5,3i4,f10.1,f10.3)') &
             & ipr,name(ipr),a(ipr),z(ipr),n(ipr),spin(ipr),qm(ipr)
        do k = 1, 3
           write(*,'(8f13.2)') (cpart(l,ipr), l=8*k-7,min(8*k,nprocs))
        end do
     end if
#endif
  end do

  close(11)

  !===
  allocate(mfrac(nucl))

  !=== All CNO elements ---> O14(35%),O15(65%) ===
  do ipr = 1, nucl
     if (      z(ipr) == 1 .and. a(ipr) ==  1 ) then
        mfrac(ipr) = 0.73d0
     else if ( z(ipr) == 2 .and. a(ipr) == 4  ) then
        mfrac(ipr) = 0.25d0
     else if ( z(ipr) == 8 .and. a(ipr) == 14 ) then
        mfrac(ipr) = 0.007d0
     else if ( z(ipr) == 8 .and. a(ipr) == 15 ) then
        mfrac(ipr) = 0.013d0
     else
        mfrac(ipr) = 0.d0
     end if
  end do


  !===== Normalize =====
  fac = 0.d0
  do ipr = 1, nucl
     fac = fac + mfrac(ipr)
  end do
  do ipr = 1, nucl
     mfrac(ipr) = mfrac(ipr)/fac
#ifdef DEBUG
     if ( ipr < 30 )  write(*,'(i5,2x,a5,2i5,es12.5)') &
          & ipr,name(ipr),z(ipr),a(ipr),mfrac(ipr)
#endif
  end do
#ifdef DEBUG
  write(*,'(5x,a,es15.7)') 'fac =',fac
#endif

  !===== Output ==================================
  write(21,'(es14.5)') 0.d0
  do k = 1, (nucl+4)/5
     write(21,'(5a14)')    (trim(name(l)), l=5*k-4,min(5*k,nucl))
     write(21,'(5es14.5)') (mfrac(l), l=5*k-4,min(5*k,nucl))
  end do


!##### PRORAM END ######################################################
  write(*,'(a)') '#### Normal Finish #####'
  stop
end program mkxrb
