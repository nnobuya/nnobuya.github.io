#define DEBUG
program mksolar
  implicit none
!##### DECLARATIVE PART ################################################

  !===== part.z =====
  character(128),parameter :: filep = '../../../part/part.z1266'
  integer,parameter :: nprt = 24
  integer :: nucl
  character(6),allocatable :: name(:)
  integer,allocatable :: a(:),z(:),n(:)
  real(8),allocatable :: spin(:),qm(:),cpart(:,:)
  real(8),allocatable :: mfrac(:)


  !===== abun_solar_sys_procs3.d =====
  character(128),parameter :: files = 'abund_solar_sys_procs3.d'
  integer,parameter :: nuclsl = 286, nprocs = 6
  character(6) :: namsl(nuclsl)
  integer :: asl(nuclsl),zsl(nuclsl),nsl(nuclsl),procs(nprocs,nuclsl)
  real(8) :: abundsl(nuclsl), mfracsl(nuclsl)


  !===== Working Variables =====
  integer :: istat,ipr,isl,k,l
  real(8) :: fac
  real(8) :: mfracCNO

  

!##### PROGRAM BEGIN ###################################################


  !===== Open the files ==========================
  !--- input files ---
  open(unit=11,file=filep   ,action='read',status='old')
  open(unit=12,file=files,action='read',status='old')

  !--- output file ---
  open(unit=21,file='iniabun_solar.z897',action='write',status='unknown')


  !===== Read the files ==========================
  !--- part.z1266 ---
  read(11,*) nucl
  allocate(name(nucl))
  allocate(a(nucl),z(nucl),n(nucl))
  allocate(spin(nucl),qm(nucl),cpart(nprt,nucl))

  do ipr = 1, nucl

     read(11,*,iostat=istat) &
          & name(ipr),a(ipr),z(ipr),n(ipr),spin(ipr),qm(ipr)
     if ( istat /= 0 ) then
        write(0,'(a)') "Error: Cannot read 'part.z*'"
        write(0,'(5x,a,i3,a,i3)') 'istat =',istat, ', ipr =',ipr
        if ( ipr /= 1 ) write(0,'(5x,a5,3i4,f10.1,f10.3)') &
             & name(ipr-1),a(ipr-1),z(ipr-1),n(ipr-1), &
             & spin(ipr-1),qm(ipr-1)
        stop 1
     end if

     do k = 1, 3
        read(11,'(8f13.2)') (cpart(l,ipr), l=8*k-7,min(8*k,nprocs))
     end do
     if ( istat /= 0 ) then
        write(0,'(a)') "Error: Cannot read 'part.z*'"
        write(0,'(5x,a,i3)') 'istat =',istat
        write(0,'(5x,a5,3i4,f10.1,f10.3)') &
             & name(ipr),a(ipr),z(ipr),n(ipr),spin(ipr),qm(ipr)
        stop 2
     end if

#ifdef DEBUG
     if ( ipr < 10 ) then
        write(*,'(i5,2x,a5,3i4,f10.1,f10.3)') &
             & ipr,name(ipr),a(ipr),z(ipr),n(ipr),spin(ipr),qm(ipr)
        do k = 1, 3
           write(*,'(8f13.2)') (cpart(l,ipr), l=8*k-7,min(8*k,nprocs))
        end do
     end if
#endif
  end do

  close(11)     


  !--- abund_solar_sys_procs3.d ---
  do k = 1, 30
     read(12,*)
  end do

  fac = 0.d0
  do isl = 1, nuclsl

     read(12,*,iostat=istat) namsl(isl),zsl(isl),asl(isl),abundsl(isl), &
          & procs(1:nprocs,isl)
     if ( istat /= 0 ) then
        write(0,'(a)') "Error: Cannot read 'abund_solar_sys_procs*.d'"
        write(0,'(5x,a,i3,a,i3)') 'istat =',istat, ', isl =',isl
        if ( isl /= 1 ) write(0,'(5x,5a,3i4,f10.1,f10.3)') &
             & namsl(isl-1),asl(isl-1),zsl(isl-1),nsl(isl-1), &
             & procs(1:nprocs,isl-1)
        stop 3
     end if

     nsl(isl) = asl(isl) - zsl(isl)

     mfracsl(isl) = abundsl(isl)*asl(isl)
     fac = fac + mfracsl(isl)
  end do

  do isl = 1, nuclsl
     mfracsl(isl) = mfracsl(isl)/fac
#ifdef DEBUG
     if ( isl < 20 )  write(*,'(i5,2x,a5,2i5,es11.4,6i4)') &
          & isl,namsl(isl),zsl(isl),asl(isl),abundsl(isl), &
          & procs(1:nprocs,isl)
#endif
  end do

  close(12)


  !===== Make the solar abundance data ===========
  allocate(mfrac(nucl))
  mfrac(:) = 0.d0
  do ipr = 1, nucl
     do isl = 1, nuclsl
        if ( z(ipr) == zsl(isl) .and. n(ipr) == nsl(isl) ) then
           mfrac(ipr) = mfracsl(isl)
           exit
        end if
     end do
  end do


  !===== Hot CNO cycle ===========================
  mfracCNO = 0.d0
  do ipr = 1, nucl
     if ( z(ipr) == 6 .or. z(ipr) == 7 .or. z(ipr) == 8 ) then
        mfracCNO = mfracCNO + mfrac(ipr)
        mfrac(ipr) = 0.d0
     end if
  end do
  
  !--- all CNO elements ---> O14(35%),O15(65%)
  do ipr = 1, nucl
     if ( z(ipr) == 8 .and. a(ipr) == 14 ) then
        mfrac(ipr) = mfracCNO * 0.35d0
     end if
     if ( z(ipr) == 8 .and. a(ipr) == 15 ) then
        mfrac(ipr) = mfracCNO * 0.65d0
     end if
  end do


  !===== Normalize =====
  fac = 0.d0
  do ipr = 1, nucl
     fac = fac + mfrac(ipr)
  end do
  do ipr = 1, nucl
     mfrac(ipr) = mfrac(ipr)/fac
#ifdef DEBUG
     if ( ipr < 30 )  write(*,'(i5,2x,a5,2i5,es12.5)') &
          & ipr,name(ipr),z(ipr),a(ipr),mfrac(ipr)
#endif
  end do
#ifdef DEBUG
  write(*,'(5x,a,es15.7)') 'fac =',fac
#endif

  !===== Output ==================================
  write(21,'(es14.5)') 0.d0
  do k = 1, (nucl+4)/5
     write(21,'(5a14)')    (trim(name(l)), l=5*k-4,min(5*k,nucl))
     write(21,'(5es14.5)') (mfrac(l), l=5*k-4,min(5*k,nucl))
  end do


!##### PRORAM END ######################################################
  write(*,'(a)') '#### Normal Finish #####'
  stop
end program mksolar
